package com.cg.bean;

import java.time.LocalDate;

public class Offer {
private String offer_type;
private int offer_id;
private LocalDate start_date;
private LocalDate end_date;
public String getOffer_type() {
	return offer_type;
}
public void setOffer_type(String offer_type) {
	this.offer_type = offer_type;
}
public int getOffer_id() {
	return offer_id;
}
public void setOffer_id(int offer_id) {
	this.offer_id = offer_id;
}
public LocalDate getStart_date() {
	return start_date;
}
public void setStart_date(LocalDate start_date) {
	this.start_date = start_date;
}
public LocalDate getEnd_date() {
	return end_date;
}
public void setEnd_date(LocalDate end_date) {
	this.end_date = end_date;
}
public Offer(String offer_type, int offer_id, LocalDate start_date, LocalDate end_date) {
	super();
	this.offer_type = offer_type;
	this.offer_id = offer_id;
	this.start_date = start_date;
	this.end_date = end_date;
}
public Offer() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Offer [offer_type=" + offer_type + ", offer_id=" + offer_id + ", start_date=" + start_date + ", end_date="
			+ end_date + "]";
}

}
