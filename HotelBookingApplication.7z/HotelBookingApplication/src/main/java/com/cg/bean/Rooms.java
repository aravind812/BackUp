package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="room")
public class Rooms {
	@Id
	@Column(name="room_id", length=10)
	private int room_id;
	@Column(name="available_room", length=10)
	private int rooms_available;
	@Column(name="price", length=10)
	private int room_price;
	@Column(name="type", length=10)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String room_type;
	
	@ManyToOne
	@JoinColumn(name="cust_room")
	private Customer cust;
	
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public int getRooms_available() {
		return rooms_available;
	}
	public void setRooms_available(int rooms_available) {
		this.rooms_available = rooms_available;
	}
	public int getRoom_price() {
		return room_price;
	}
	public void setRoom_price(int room_price) {
		this.room_price = room_price;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	@Override
	public String toString() {
		return "Rooms [room_id=" + room_id + ", rooms_available=" + rooms_available + ", room_price=" + room_price
				+ ", room_type=" + room_type + "]";
	}
	public Rooms(int room_id, int rooms_available, int room_price, String room_type) {
		super();
		this.room_id = room_id;
		this.rooms_available = rooms_available;
		this.room_price = room_price;
		this.room_type = room_type;
	}
	public Rooms() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
