package com.cg.bean;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	@Column(name="cust_id", length=10)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custId;
	
	@Column(name="fname", length=15)
	private String firstName;
	
	@Column(name="lname", length=10)
	private String lastName;
	
	@Column(name="dob", length=10)
	private Date dob;
	
	@Column(name="gender", length=6)
	private String gender;
	
	@Column(name="email", length=30)
	private String emailId;
	
	@Column(name="phn_no", length=10)
	private long phoneNo;
	
	@Column(name="addr", length=50)
	private String address;
	
	@Column(name="pass", length=16)
	private String password;
	
	@Column(name="cpass", length=16)
	private String cPassword;
	
	@OneToMany(mappedBy="cust",cascade=CascadeType.ALL)
	private Set<Room> roomSet=new HashSet<Room>();

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getcPassword() {
		return cPassword;
	}

	public void setcPassword(String cPassword) {
		this.cPassword = cPassword;
	}

	public Set<Room> getRoomSet() {
		return roomSet;
	}

	public void setRoomSet(Set<Room> roomSet) {
		this.roomSet = roomSet;
	}

	public Customer(int custId, String firstName, String lastName, Date dob, String gender, String emailId,
			long phoneNo, String address, String password, String cPassword, Set<Room> roomSet) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.gender = gender;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.address = address;
		this.password = password;
		this.cPassword = cPassword;
		this.roomSet = roomSet;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob
				+ ", gender=" + gender + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", address=" + address
				+ ", password=" + password + ", cPassword=" + cPassword + ", roomSet=" + roomSet + "]";
	}
		
	
}
