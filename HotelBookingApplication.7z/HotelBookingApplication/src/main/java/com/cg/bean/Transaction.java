package com.cg.bean;

import java.sql.Date;

public class Transaction {

	private int transId;
	private Date transtime;
	private String transType;
}
