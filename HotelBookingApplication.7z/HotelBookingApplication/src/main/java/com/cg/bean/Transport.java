package com.cg.bean;

import java.time.LocalDate;

public class Transport {
	private int transport_id;
	private int price;
	private String vehicle_name;
	private String source;
	private String destination;
	private LocalDate date;
	private LocalDate time;
	public int getTransport_id() {
		return transport_id;
	}
	public void setTransport_id(int transport_id) {
		this.transport_id = transport_id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getVehicle_name() {
		return vehicle_name;
	}
	public void setVehicle_name(String vehicle_name) {
		this.vehicle_name = vehicle_name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalDate getTime() {
		return time;
	}
	public void setTime(LocalDate time) {
		this.time = time;
	}
	public Transport(int transport_id, int price, String vehicle_name, String source, String destination,
			LocalDate date, LocalDate time) {
		super();
		this.transport_id = transport_id;
		this.price = price;
		this.vehicle_name = vehicle_name;
		this.source = source;
		this.destination = destination;
		this.date = date;
		this.time = time;
	}
	public Transport() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Transport [transport_id=" + transport_id + ", price=" + price + ", vehicle_name=" + vehicle_name
				+ ", source=" + source + ", destination=" + destination + ", date=" + date + ", time=" + time + "]";
	}

}
