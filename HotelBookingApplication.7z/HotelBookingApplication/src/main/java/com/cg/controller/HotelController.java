package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Customer;
import com.cg.bean.Room;
import com.cg.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	IHotelService custSer=null;

	public IHotelService getCustSer() {
		return custSer;
	}

	public void setCustSer(IHotelService custSer) {
		this.custSer = custSer;
	}
	
	@RequestMapping(value="/ShowHome")
	public String showHome(Model model) {
		return "home";
		
	}
	
	@RequestMapping(value="/showLogin")
	public String dispLoginPage(Model model) {
		
		Customer cust=new Customer();
		
		model.addAttribute("hotelObj", cust);
		return "login";
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(value="/ValidateLogin")
	public String isLogin(@ModelAttribute("hotelObj") Customer cus,Model model) {
		
		System.out.println("customer id:"+cus.getCustId()+" email Id"+cus.getEmailId()+"pass: "+cus.getPassword());
		Room room=new Room();
		Customer cust=custSer.validateCustomer(cus);
		System.out.println("password :"+cust.getPassword());
		if(cust!=null) {
			if(cust.getPassword().equals(cus.getPassword())) {
				
				model.addAttribute("hotelObj",room);
				String msg="Welcome "+cust.getEmailId()+" custId :"+cust.getCustId();
				model.addAttribute("MsgObj",msg);
				return "roomBooking";
			}
			else {
				String msg="Sorry Invalid Password";
				model.addAttribute("MsgObj",msg);
				return "login";
			}
			
		}else {
			return "createProfile";
		}
	}
	@RequestMapping(value="/CreateProfile")
	public String showProfile(Model model) {
		
		Customer cust=new Customer();
		
		model.addAttribute("hotelObj", cust);
		return "createProfile";
	}
	
	@RequestMapping(value="/AddProfile")
	public String addProfile(@ModelAttribute("hotelObj") Customer cus,Model model ) {
		custSer.createProfile(cus);
		return "login";
	}
/*
	@RequestMapping(value="/adminLogin")
	public String adminLogin(Model model) {
		return "admin";
	}*/
	
	@RequestMapping(value="/bookRoom")
	public String bookInRoom(@ModelAttribute("hotelObj") Room room,Model model){
		
		/*String sMsg="Your room is booked Successfully";
		model.addAttribute("MsgObj",sMsg);
		custSer.bookInRoom(room);*/
		return "roomBooking";
	}
	
	@RequestMapping(value="/userHome")
	public String DisUserHome(@ModelAttribute("hotelObj") Room room,Model model) {
		
		Room rm =new Room();
		model.addAttribute("hotelObj", room);
		custSer.bookInRoom(room);
		String sMsg="Your room is booked Successfully & This is your room Id :"+room.getRoomId();
		model.addAttribute("MsgObj",sMsg);
		return "userHome";
	}
	
	@RequestMapping(value="/viewUser")
	public String viewUser(@ModelAttribute("hotelObj") Room room,Model model) {
		System.out.println("Room Id: "+room.getRoomId());
		List list =custSer.getRommDetails(room);
		model.addAttribute("list",list);
		return "view";
	}
}
