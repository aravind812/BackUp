package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Customer;
import com.cg.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	IHotelService custSer=null;

	public IHotelService getCustSer() {
		return custSer;
	}

	public void setCustSer(IHotelService custSer) {
		this.custSer = custSer;
	}
	
	@RequestMapping(value="/ShowHome")
	public String showHome(Model model) {
		return "home";
		
	}
	
	@RequestMapping(value="/showLogin")
	public String dispLoginPage(Model model) {
		
		Customer cust=new Customer();
		
		model.addAttribute("hotelObj", cust);
		return "login";
	}
	
	@RequestMapping(value="/ValidateLogin")
	public String isLogin(@ModelAttribute("hotelObj") Customer cus,Model model) {
		
		Customer cust=custSer.validateCustomer(cus);
		if(cust!=null) {
			return "login";
		}
		else {
			return "createProfile";
		}
	}

	@RequestMapping(value="/CreateProfile")
	public String addProfile(Model model) {
		
		Customer cust=new Customer();
		
		model.addAttribute("hotelObj", cust);
		return "createProfile";
	}
	
	
}
