package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Customer;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao{

	@PersistenceContext
	EntityManager em=null;
	
	public EntityManager getEm() {
		return em;
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}


	public HotelDaoImpl() {
		super();
		
	}


	@Override
	public Customer createProfile(Customer cust) {
	em.persist(cust);
		return cust;
	}


	@Override
	public Customer validateCustomer(Customer cus) {
		Customer cust=em.find(Customer.class, cus.getCustId());
		return cust;
	}

	

}
