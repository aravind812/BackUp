package com.cg.dao;

import com.cg.bean.Customer;

public interface IHotelDao {

	public Customer createProfile(Customer cust);
	
	public Customer validateCustomer(Customer cust);

	public Customer getCustomer(String emailId);
}
