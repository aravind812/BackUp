package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.HotelDaoImpl;
import com.cg.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService{

	@Autowired
	IHotelDao dao;
	Customer customer;
	
	public HotelServiceImpl() {
		super();
		dao = new HotelDaoImpl();
	}


	@Override
	public Customer createProfile(Customer cust) {
		Customer cus=dao.createProfile(cust);
		return cus;
	
	}


	@Override
	public Customer validateCustomer(Customer cust) {
		
		return dao.validateCustomer(cust);
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public boolean verifyPassword(String emailId, String password) {
			customer = dao.getCustomer(emailId);
			if (customer == null)
				System.out.println("Customer does not exist");
			if (customer.getPassword().equals(password))
				return true;
			else
				return false;
		}
	
}
