package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.HotelDaoImpl;
import com.cg.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService{

	@Autowired
	IHotelDao dao;
	
	
	public HotelServiceImpl() {
		super();
		dao = new HotelDaoImpl();
	}


	@Override
	public Customer createProfile(Customer cust) {
		
		return null;
	}


	@Override
	public Customer validateCustomer(Customer cust) {
		
		return dao.validateCustomer(cust);
	}

	
}
