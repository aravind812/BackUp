package com.cg.service;

import com.cg.bean.Customer;

public interface IHotelService {

	public Customer createProfile(Customer cust);
	
	public Customer validateCustomer(Customer cust);

	public boolean verifyPassword(String emailId, String password);
	
}
