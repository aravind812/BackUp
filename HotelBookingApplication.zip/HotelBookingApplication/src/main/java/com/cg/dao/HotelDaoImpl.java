package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Customer;
import com.cg.bean.Room;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao {

	@PersistenceContext
	EntityManager em = null;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	public HotelDaoImpl() {
		super();
	}

	@Override
	public Customer createProfile(Customer cust) {
		em.persist(cust);
		return cust;
	}

	@Override
	public Customer validateCustomer(Customer cus) {
		/*
		 * String sel="select cm from Customer cm where emailId="+cus.getEmailId();
		 * TypedQuery<Customer> tyQry=em.createQuery(sel,Customer.class); Customer
		 * cust=tyQry.getFirstResult();
		 */
		Customer cust = em.find(Customer.class, cus.getCustId());
		return cust;
	}

	@Override
	public Room bookInRoom(Room room) {
		em.persist(room);
		return room;
	}

	@Override
	public List<Room> getRommDetails(Room room) {
		String sel = "select rm from room rm where roomId=" + room.getRoomId();
		TypedQuery<Room> tyQry = em.createQuery(sel, Room.class);
		List<Room> list = (List<Room>) tyQry.getResultList();
		return list;
	}

}
