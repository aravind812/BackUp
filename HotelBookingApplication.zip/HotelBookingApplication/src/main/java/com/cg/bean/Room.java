package com.cg.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="room")
public class Room {

	@Id
	@Column(name="room_id", length=10)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int roomId;
	
	@Column(name="room_type", length=10)
	private String roomType;
	
	@Column(name="room_status", length=10)
	private String roomStatus;
	
	@Column(name="room_price", length=10)
	private double roomPrice;
	
	@Column(name="avail_rooms", length=10)
	private int availableRoom;
	
	@Column(name="check_in", length=10)
	private Date checkIn;
	
	@Column(name="check_out", length=10)
	private Date checkOut;
	
	@ManyToOne
	private Customer cust;
	
	//***GETTER SETTER METHOD
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getRoomStatus() {
		return roomStatus;
	}
	public void setRoomStatus(String roomStatus) {
		this.roomStatus = roomStatus;
	}
	public double getRoomPrice() {
		return roomPrice;
	}
	public void setRoomPrice(double roomPrice) {
		this.roomPrice = roomPrice;
	}
	public int getAvailableRoom() {
		return availableRoom;
	}
	public void setAvailableRoom(int availableRoom) {
		this.availableRoom = availableRoom;
	}
	public Date getCheckIn() {
		return checkIn;
	}
	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}
	public Date getCheckOut() {
		return checkOut;
	}
	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}
	
	//***DEFAULT CONSTRUCTOR*** 
	public Room() {
		super();
	}
	
	//***PARAMETERISED CONSTRUCTOR***
	public Room(int roomId, String roomType, String roomStatus, double roomPrice, int availableRoom, Date checkIn,
			Date checkOut) {
		super();
		this.roomId = roomId;
		this.roomType = roomType;
		this.roomStatus = roomStatus;
		this.roomPrice = roomPrice;
		this.availableRoom = availableRoom;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
	}
	
	//***toSTRING METHOD***
	@Override
	public String toString() {
		return "Room [roomId=" + roomId + ", roomType=" + roomType + ", roomStatus=" + roomStatus + ", roomPrice="
				+ roomPrice + ", availableRoom=" + availableRoom + ", checkIn=" + checkIn + ", checkOut=" + checkOut
				+ "]";
	}
	
	
}
