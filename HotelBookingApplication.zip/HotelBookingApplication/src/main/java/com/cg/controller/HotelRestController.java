package com.cg.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Room;
import com.cg.service.IHotelService;

@RestController
public class HotelRestController {

	@Autowired
	IHotelService custSer = null;

	public IHotelService getCustSer() {
		return custSer;
	}

	public void setCustSer(IHotelService custSer) {
		this.custSer = custSer;
	}

	Room room = new Room();

	@RequestMapping(value = "/roomDetails", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Room>> getRoom() {
		HttpHeaders headers = new HttpHeaders();
		List<Room> rList = custSer.getRommDetails(room);
		if (rList == null) {
			return new ResponseEntity<List<Room>>(HttpStatus.NOT_FOUND);
		}
		headers.add("Number Of Records Found", String.valueOf(((Map<String, List<String>>) room).size()));
		return (ResponseEntity<List<Room>>) rList;
	}

}